#!/bin/bash

hookbox --admin-password=hookboxdemo --cb-connect=connect.php --cb-create_channel=create_channel.php --cb-subscribe=subscribe.php --cb-unsubscribe=unsubscribe.php --cb-publish=publish.php --cb-disconnect=disconnect.php --debug
