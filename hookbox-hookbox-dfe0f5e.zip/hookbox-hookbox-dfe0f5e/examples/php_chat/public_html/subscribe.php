<?php

print '[true,{}]';

?>