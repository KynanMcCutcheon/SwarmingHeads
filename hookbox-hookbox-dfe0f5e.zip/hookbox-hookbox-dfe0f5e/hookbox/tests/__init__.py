# load all modules to get them into the coverage report
import hookbox
from hookbox import admin
from hookbox import channel
from hookbox import config
from hookbox import errors
from hookbox import protocol
from hookbox import rest
from hookbox import server
from hookbox import start
from hookbox import user

