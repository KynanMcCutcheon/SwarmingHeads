class ExpectedException(Exception):
    pass