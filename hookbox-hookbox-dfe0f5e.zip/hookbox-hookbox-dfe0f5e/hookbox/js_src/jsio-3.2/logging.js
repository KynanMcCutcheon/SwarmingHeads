exports.UIWatcher = Class(function() {
	
});